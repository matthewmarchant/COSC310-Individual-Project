import javax.swing.*;

public class Cashier {
    private JFormattedTextField formattedTextField1;
    private JButton button1;
    private JButton button2;
}
