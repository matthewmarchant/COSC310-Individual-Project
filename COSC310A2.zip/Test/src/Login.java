import javax.swing.*;

public class Login {
    private JPasswordField passwordField;
    private JFormattedTextField COSC310LoginFormattedTextField;
    private JButton cashierLoginButton;
    private JButton managerLoginButton;
    private JFormattedTextField usernameFormattedTextField;
    private JFormattedTextField passwordFormattedTextField;
    JPanel LoginPanel;
    private JTextPane textPane1;
    private JFormattedTextField usernameFormattedTextField1;
}
